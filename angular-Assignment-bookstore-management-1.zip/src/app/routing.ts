import {
  Routes,
  RouterModule,
  PreloadAllModules,
  NoPreloading
} from "@angular/router";
import { ModuleWithProviders } from "@angular/core";
import { BookComponent } from './book/book.component';
import { AddBookComponent } from './add-book/add-book.component';
import { EditBookComponent } from './edit-book/edit-book.component';
import { HomePageComponent } from "./home-page/home-page.component";
import { NotesComponent } from "./notes/notes.component";
const APP_LAZY_ROUTES: Routes = [
  { path: "", component: HomePageComponent },
  { path: "add", component: AddBookComponent },
  { path: "edit/:id", component: EditBookComponent },
  {path: "home", component: BookComponent},
  {path:"notes",component:NotesComponent}
];

export const APP_LAZY_ROUTING: ModuleWithProviders = RouterModule.forRoot(
  APP_LAZY_ROUTES,
  {
    preloadingStrategy: NoPreloading
  }
);
