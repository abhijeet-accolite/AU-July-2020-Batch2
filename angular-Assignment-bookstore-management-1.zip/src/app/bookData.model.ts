export const BookData = [
  { bookId: 1,bookTitle: "xyz", edition: "abc ", author: "mr b",price:10,publisher:"mr b",bookCount:20 },
];