# angular-bookstore-management

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/angular-bookstore-management)